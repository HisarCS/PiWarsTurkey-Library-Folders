# PiWars Turkiye 2019: python library for the distributed robot kit by HisarCS

This python library was created for the purposes of easing the understanding between software, sensors and movables on the robot kits designed by HisarCS for attendees of Pi Wars Turkey 2019.

## mkslm

ljdlvd

## kjndkjn

dlkflk
